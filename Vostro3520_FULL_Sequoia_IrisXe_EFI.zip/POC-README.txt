Dell Vostro 3520 / i5-1235U - Sequoia final ICLLP Fake-ID experiment

Last-resort adaptation of the InsanelyMac Tiger Lake research: spoof Alder Lake GPU DEV_4628 as ICLLP 0x9A49 and inject ICLLP platform-id 0x8A520000. Uses lshbluesky/WhateverGreen fork and forum graphics arguments.

This is NOT confirmed for Alder Lake. The original research used Tiger Lake 0x9A49 and did not achieve full QE/CI; it reported framebuffer/basic display and black-screen/crash issues. This EFI deliberately omits -igfxvesa to attempt framebuffer loading. If it fails, restore the previous EFI.

Keep this on USB only. Do not overwrite Windows EFI. The OS.dmg.root_hash Err(0xE) problem occurs before this GPU stage and is unaffected.

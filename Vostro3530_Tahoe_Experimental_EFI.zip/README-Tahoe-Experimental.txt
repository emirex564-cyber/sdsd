Dell Vostro 3530 / Intel i5-1235U Alder Lake experimental Tahoe EFI

This is a boot experiment, not a guaranteed working Hackintosh EFI. Alder Lake Iris Xe has no native macOS graphics driver. -igfxvesa requests basic VESA-style display only; QE/CI/Metal is not expected.

Changes in this variant: SetupVirtualMap=False; AppleCpuPmCfgLock=True; AppleXcpmCfgLock=True; LapicKernelPanic=True; ProvideCurrentCpuInfo=True; boot-args include -igfxvesa.

SSDT-XOSI.aml was NOT added because it is not present in this EFI and a fake ACPI table would be unsafe. SMBIOS values are placeholders and MUST be regenerated with GenSMBIOS before normal use.

Test first from USB. Keep a backup of the Windows EFI.

Dell Vostro 3530 / i5-1235U Alder Lake - FakeIrisXEFramebuffer test

Added pre-release FakeIrisXEFramebuffer 11.7. Its original personality matches 0x9A498086 (Tiger Lake-style), so this test injects device-id 499a0000 at PciRoot(0x0)/Pci(0x2,0x0) to attempt loading it.

WARNING: This is not an Alder Lake driver and does not guarantee display, QE/CI, Metal, or Tahoe compatibility. It may cause a black screen, GPU panic, or boot hang. Test from USB only. Remove FakeIrisXEFramebuffer.kext or boot the previous lshbluesky-WEG EFI to recover.

The existing lshbluesky WhateverGreen fork remains enabled. This test is for evidence collection, not a production EFI.

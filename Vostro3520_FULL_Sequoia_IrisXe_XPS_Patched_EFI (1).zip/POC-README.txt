Dell Vostro 3520 / i5-1235U - Sequoia full experimental EFI

Added only portable items observed in the Dell XPS 13 9300 project: hda-gfx=onboard-1, enable-hdmi20, DeduplicateBootOrder, ReleaseUsbOwnership and RequestBootVarRouting.

Not copied: XPS Ice Lake 0x8A51 device-id/platform-id, XPS-only framebuffer memory values, XPS ACPI tables, PS2/I2C/ALS/Thunderbolt tables. Those are hardware-specific and could break this Vostro.

The EFI retains the Alder Lake CPUID emulation, ICLLP Fake-ID experiment, fork WhateverGreen, SSDT-PLUG-ALT, and iGPU-enabled Sequoia boot args. Experimental only; no full Iris Xe QE/CI is guaranteed.

Dell Vostro 3530 / i5-1235U Alder Lake experimental fork variant

Integrated lshbluesky/WhateverGreen release v1.6.7-d8 (Debug). The fork source contains a model table entry for device 0x4628 with fake ID 0x8A5A. This only affects WhateverGreen model detection/spoof logic; it does NOT add a native Alder Lake Apple framebuffer or Metal/QE/CI driver.

The binary is debug, not a production build. Boot with -v and collect WhateverGreen logs. If the system panics or black-screens, revert to the standard WhateverGreen variant. Test from USB only.

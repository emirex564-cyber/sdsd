Dell Vostro 3530 / i5-1235U Tahoe debug EFI

Added Acidanthera DebugEnhancer 1.1.1 DEBUG. Boot args: -dbgenhdbg -dbgenhbeta -dbgenhiolog msgbuf=1048576.

This kext enables extra macOS kernel/IOLog output; it does not repair EXITBS, installer root_hash errors, or Iris Xe graphics. DebugEnhancer loads after the kernel starts, so it cannot fix a failure that happens before kernel handoff. Use the verbose screen and photograph the last lines. Test from USB only.

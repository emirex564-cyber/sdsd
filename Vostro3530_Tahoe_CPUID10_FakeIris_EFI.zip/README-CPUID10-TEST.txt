Dell Vostro 3530 / i5-1235U Alder Lake - CPUID 10th Gen spoof test

Applied the video values: Cpuid1Data=E0060900000000000000000000000000 and Cpuid1Mask=FFFFFFFF000000000000000000000000. Added revpatch=pci,sbvmm.

This is a separate test variant layered on the FakeIrisXEFramebuffer test EFI. CPUID spoof only changes the CPU identity presented to macOS; it does not add Alder Lake Iris Xe graphics support. It can cause a boot loop or kernel panic. Test via USB and keep the previous EFI.

If this fails earlier than the original, revert to the prior EFI. If it boots, report the last verbose line and whether the installer display appears.

Dell Vostro 3520 / i5-1235U - experimental PCI-root Iris Xe variant

Added PciRoot(0x0)/Pci(0x2,0x0) with conservative iGPU properties and the comment-suggested debug/graphics boot arguments. Latitude 3420 framebuffer patches were intentionally NOT copied because they are device-specific.

This does not prove or guarantee Alder Lake Iris Xe acceleration. If the screen goes black or it stops booting, restore the previous EFI variant. The OS.dmg.root_hash Err(0xE) installer error occurs before these macOS graphics settings can have any effect.

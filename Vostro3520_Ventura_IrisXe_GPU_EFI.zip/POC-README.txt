Dell Vostro 3520 / i5-1235U - Ventura GPU-enabled experimental POC

This variant is for macOS Ventura, not Tahoe. It keeps the lshbluesky/WhateverGreen v1.6.7-d8 Debug fork, enables the internal GPU path, adds PciRoot(0x0)/Pci(0x2,0x0) conservative properties, and DOES NOT use -wegnoigpu.

The Alder Lake CPUID emulation, ProvideCurrentCpuInfo and SSDT-PLUG-ALT settings remain. This is experimental: the fork does not guarantee full acceleration for Intel DEV_4628, and the laptop may show a black screen or VESA/no acceleration.

Use only on USB and keep the previous EFI backup. If it fails, restore the previous EFI.

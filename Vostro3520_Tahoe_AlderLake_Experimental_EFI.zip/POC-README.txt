Dell Vostro 3520 / i5-1235U - experimental Alder Lake POC

This package uses SchmockLord's Alder Lake base plus: Comet Lake CPUID emulation, ProvideCurrentCpuInfo, SSDT-PLUG-ALT, MacPro7,1 SMBIOS, and -wegnoigpu.

IMPORTANT: This is experimental and does not add Intel Alder Lake iGPU support. The internal Intel GPU (DEV_4628) is disabled; without a supported AMD dGPU, macOS may boot with no usable accelerated display. Realtek RTL8821CE Wi-Fi is unsupported; use RTL8168 Ethernet if available.

The photographed EB|RH:LRH Err(0xE) OS.dmg.root_hash error happens before the kernel and is not fixed by CPU patches. If it remains, rebuild the Recovery/Installer files and verify the USB.

Use only on USB. Keep the Windows EFI backup.

Dell Vostro 3520 / i5-1235U - Sequoia iGPU VESA installer POC

Adapted from the supplied ThinkPad T14 Gen 2 report. GPU stays enabled. Added -igfxvesa for basic/VESA display fallback, UEFI DisableSecurityPolicy, and Kernel AppleXcpmExtraMsrs. Kept Alder Lake Comet Lake CPUID emulation and lshbluesky WhateverGreen.

The supplied report is Tiger Lake i5-1145G7, not Alder Lake i5-1235U. Therefore its E5060700 CPU ID and device-specific framebuffer patches were not copied. Full Iris Xe QE/CI/Metal is not guaranteed.

Use only from USB and keep a known-good EFI backup. If this boots, it is likely basic display without acceleration. After installation, remove -igfxvesa and test normal framebuffer separately.

AGGRESSIVE EXITBS EXPERIMENT - Dell Vostro 3530 / i5-1235U

This is a separate experimental variant. It adds the requested MMIO whitelist entries 0xFF000000 and 0xFF600000, forces SetupVirtualMap=False, enables CFG-lock quirks, and adds npci=0x2000 cpus=1.

WARNING: The MMIO addresses are not verified against this laptop's actual UEFI memory map. Incorrect whitelisting can cause a hang, reboot, or firmware/boot failure. cpus=1 is only for diagnosis and severely limits CPU use. Do not install this to the internal disk until it boots from USB.

If it still stops at EXITBS or OS.dmg.root_hash Err(0xE), do not keep adding random quirks; capture the complete log and verify the Recovery/installer media and OpenCore version.

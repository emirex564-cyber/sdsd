Dell Vostro 3520 / i5-1235U - macOS Tahoe POC

This is a USB-only EXPERIMENT based on SchmockLord's Alder Lake base EFI.
It is NOT a full-support EFI. The report identifies Intel iGPU DEV_4628,
which has no native macOS graphics acceleration, and Realtek RTL8821CE Wi-Fi,
which is not supported by AirportItlwm. Use Ethernet for the installer.

Do not install this EFI to the internal disk. Copy the EFI folder to the USB
EFI partition only. Keep a backup of the original EFI. If the picker is blank,
press Space. Reset NVRAM only from OpenCore if necessary.

The included config is a base configuration, not a verified Dell ACPI/USB map.
For daily use, use a real device-specific EFI and a supported GPU/platform.
